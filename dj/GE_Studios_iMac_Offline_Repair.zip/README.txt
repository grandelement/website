GE STUDIOS IMAC HELPER V10 - OFFLINE INSTALLER

This ZIP includes the actual uploader. No Github or ChatGPT required on the
2007 iMac. No Terminal commands.

1. Finish any transfer in the GE DJ Booth.
2. In Firefox on the iMac, click ONE-TIME IMAC HELPER UPDATE in STATUS.
3. Unzip the package from Downloads.
4. Control-click GE Studios OFFLINE Repair.app and choose Open.
5. Click Install. Refresh the GE DJ Booth.
6. STATUS should report HELPER V10.
7. Choose DRAFT / RADIO / FINAL format; set album, track, metadata and cover,
   then SAVE SETTINGS before uploading.

No originals, playlists, radio station, rclone config, or Google Drive files
are erased. A local backup of the older helper is made first.
If rclone needs Google authorization, use FIX GOOGLE DRIVE in STATUS.
The browser settings currently save locally; Vault sync is not configured.
