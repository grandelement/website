#!/bin/bash
# GE Studios Music Library for OS X 10.11 El Capitan.
set -eu
cd "$(dirname "$0")"
BASE="$HOME/Library/Application Support/GEStudios"
PLIST="$HOME/Library/LaunchAgents/com.grandelement.geuploads.plist"
TOKEN="$BASE/github-radio-token"
umask 077
mkdir -p "$BASE" "$HOME/Library/LaunchAgents"
if [ ! -s "./ge-upload-helper.py" ] || [ ! -s "./ge-radio-github.py" ]; then
 echo "Missing files. Unzip the complete GE Studios Library Installer first."
 read -p "Press Return to close..." answer
 exit 1
fi
cp "./ge-upload-helper.py" "$BASE/ge-upload-helper.py"
cp "./ge-radio-github.py" "$BASE/ge-radio-github.py"
chmod 600 "$BASE/ge-upload-helper.py" "$BASE/ge-radio-github.py"
/usr/bin/python -m py_compile "$BASE/ge-upload-helper.py" "$BASE/ge-radio-github.py" || {
 echo "Python validation FAILED. The old uploader was not restarted."
 read -p "Press Return to close..." answer
 exit 1
}
/usr/bin/python - "$BASE/ge-upload-helper.py" "$PLIST" <<'PY'
import plistlib,sys
p,path=sys.argv[1:]
plistlib.writePlist({
  "Label":"com.grandelement.geuploads",
  "ProgramArguments":["/usr/bin/python",p],
  "RunAtLoad":True,"KeepAlive":True,"ThrottleInterval":30,
  "StandardOutPath":"/tmp/ge-studios-uploads.log",
  "StandardErrorPath":"/tmp/ge-studios-uploads-error.log"
},path)
PY
chmod 600 "$PLIST"
/bin/launchctl unload "$PLIST" >/dev/null 2>&1 || true
if /bin/launchctl load -w "$PLIST"; then
 echo "GE STUDIO HELPER INSTALLED AND STARTED."
else
 echo "WARNING: LaunchAgent did not start. See /tmp/ge-studios-uploads-error.log"
fi
if ! [ -s "$TOKEN" ] || ! /usr/bin/python "$BASE/ge-radio-github.py" --check >/dev/null 2>&1; then
 echo "GitHub token not connected. Create a fine-grained token in Firefox:"
 echo "https://github.com/settings/personal-access-tokens/new"
 echo "Repository: grandelement/website. Permission: Contents (Read and write)."
 secret=$(/usr/bin/osascript -e 'text returned of (display dialog "Paste your GitHub fine-grained token. Choose grandelement/website and Contents: Read and write in GitHub settings. The token stays private on this Mac." default answer "" buttons {"Skip", "Save"} default button "Save" with hidden answer)' 2>/dev/null) || secret=""
 if [ -n "$secret" ]; then
   printf '%s' "$secret" > "$TOKEN"
   chmod 600 "$TOKEN"
 fi
 unset secret
fi
echo ""
echo "CHECKING GITHUB CONNECTION..."
if /usr/bin/python "$BASE/ge-radio-github.py" --check; then
 echo "CONNECTED. The first real song upload will test GitHub write permission."
else
 echo "NOT CONNECTED. Create a fine-grained GitHub token and run this installer again."
fi
echo ""
echo "On your iMac, open https://grandelement.com/dj/imac.html?tab=library"
echo "You can upload new AIF songs or replace existing MP3 tracks there."
echo "NOTE: Radio 1 and Radio 2 rotation is separate from the music library."
read -p "Press Return to close..." answer
