#!/bin/bash
# GE Studios Library installer for OS X El Capitan (10.11). No administrator access.
set -eu
cd "$(dirname "$0")"
BASE="$HOME/Library/Application Support/GEStudios"
AGENTS="$HOME/Library/LaunchAgents"
PLIST="$AGENTS/com.grandelement.geuploads.plist"
TOKEN="$BASE/github-radio-token"
umask 077
mkdir -p "$BASE" "$AGENTS"
if [ ! -s "./ge-upload-helper.py" ] || [ ! -s "./ge-radio-github.py" ]; then
 echo "INSTALL FAILED: Unzip the whole GE Studios Library Installer first."
 read -p "Press Return to close..." answer
 exit 1
fi
cp "./ge-upload-helper.py" "$BASE/ge-upload-helper.py"
cp "./ge-radio-github.py" "$BASE/ge-radio-github.py"
chmod 600 "$BASE/ge-upload-helper.py" "$BASE/ge-radio-github.py"
if ! /usr/bin/python -m py_compile "$BASE/ge-upload-helper.py" "$BASE/ge-radio-github.py"; then
 echo "INSTALL FAILED: Python syntax check failed. Helper not restarted."
 read -p "Press Return to close..." answer
 exit 1
fi
/usr/bin/python - "$BASE/ge-upload-helper.py" "$PLIST" <<'PY'
import plistlib,sys
program,location=sys.argv[1:]
plistlib.writePlist({
    "Label":"com.grandelement.geuploads",
    "ProgramArguments":["/usr/bin/python",program],
    "RunAtLoad":True,"KeepAlive":True,"ThrottleInterval":30,
    "StandardOutPath":"/tmp/ge-studios-uploads.log",
    "StandardErrorPath":"/tmp/ge-studios-uploads-error.log"
},location)
PY
chmod 600 "$PLIST"
launchctl unload "$PLIST" >/dev/null 2>&1 || true
if ! launchctl load -w "$PLIST"; then
 echo "WARNING: Mac did not start the helper. See /tmp/ge-studios-uploads-error.log"
fi
echo "GE STUDIOS LIBRARY HELPER INSTALLED."
if [ ! -s "$TOKEN" ]; then
 echo "GitHub requires your own fine-grained access token."
 echo "In Firefox open: https://github.com/settings/personal-access-tokens/new"
 echo "Allow ONLY grandelement/website with Contents: Read and write."
 secret=$(/usr/bin/osascript -e 'text returned of (display dialog "Paste your GitHub fine-grained token. Repository: grandelement/website. Contents: Read and write. Never share the token in chat." default answer "" buttons {"Skip", "Save"} default button "Save" with hidden answer)' 2>/dev/null) || secret=""
 if [ -n "$secret" ]; then
  printf '%s' "$secret" > "$TOKEN"
  chmod 600 "$TOKEN"
 fi
 unset secret
fi
echo ""
echo "TESTING PRIVATE GITHUB CONNECTION"
/usr/bin/python "$BASE/ge-radio-github.py" --check || true
echo ""
echo "Now open https://grandelement.com/dj/imac.html?tab=library"
echo "Use CHECK GITHUB, then choose your AIF to upload or replace."
echo "If the check fails, create a GitHub token with Contents: Read and write, then run this installer again."
read -p "Press Return to close..." answer
