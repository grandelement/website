on run
    set macHome to POSIX path of (path to home folder)
    set rclonePath to macHome & "Downloads/rclone-v1.52.0-osx-amd64/rclone"
    set configPath to macHome & ".config/rclone/rclone.conf"
    set driveRemote to "GEStudios:"
    try
        do shell script "/bin/test -x " & quoted form of rclonePath & " && /bin/test -f " & quoted form of configPath
    on error
        display dialog "The GE Studios rclone application or Google Drive configuration was not found in its expected location. No changes were made." buttons {"OK"} default button "OK" with icon caution
        return
    end try
    set choice to display dialog "Reconnect GE Studios to Google Drive? This runs without Terminal and does not erase music, playlists, or Google Drive files. Google may ask you to sign in." buttons {"Cancel", "Reconnect"} default button "Reconnect" with icon note
    if button returned of choice is not "Reconnect" then return
    try
        with timeout of 600 seconds
            do shell script quoted form of rclonePath & " --config " & quoted form of configPath & " --auto-confirm config reconnect " & quoted form of driveRemote & " >/dev/null 2>&1"
        end timeout
    on error
        display dialog "Google sign-in did not complete. Your files were not deleted. Check whether Google opened a sign-in page in the iMac browser." buttons {"OK"} default button "OK" with icon caution
        return
    end try
    try
        with timeout of 90 seconds
            do shell script quoted form of rclonePath & " --config " & quoted form of configPath & " about " & quoted form of driveRemote & " >/dev/null 2>&1"
        end timeout
        display dialog "GOOGLE DRIVE CONNECTED. Return to the GE DJ Booth GOOGLE tab and retry the upload." buttons {"OK"} default button "OK" with icon note
    on error
        display dialog "Google sign-in finished, but the Drive connection could not be confirmed. No recordings were removed." buttons {"OK"} default button "OK" with icon caution
    end try
end run
